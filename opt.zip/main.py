import ctypes
import numpy as np
import pandas as pd

# Load the shared library
lib = ctypes.CDLL("./lib/opt.so")  # Make sure the shared library is compiled as "functions.so"

# Define function prototypes
lib.f.restype = ctypes.c_double
lib.f.argtypes = [ctypes.POINTER(ctypes.c_double), ctypes.c_int]

lib.init.restype = None
lib.init.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_double]

lib.stop.restype = None
lib.stop.argtypes = None

lib.optimize.restype = None
lib.optimize.argtypes = [ctypes.POINTER(ctypes.c_double), 
                         ctypes.POINTER(ctypes.c_double),
                         ctypes.POINTER(ctypes.c_double), 
                         ctypes.POINTER(ctypes.c_double), 
                         ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_double, ctypes.c_double, ctypes.c_int]

lib.f.restype = None
lib.f.argtypes = [ctypes.POINTER(ctypes.c_double), 
                         ctypes.POINTER(ctypes.c_double),
                         ctypes.POINTER(ctypes.c_double), 
                         ctypes.POINTER(ctypes.c_double), 
                         ctypes.c_int, 
                         ctypes.c_int, 
                         ctypes.POINTER(ctypes.c_double),
                         ctypes.c_int
                  ]
# Example usage
#w = np.array([1.5, 1.1, -1.3]) #np.random.randn(3)  # Example initial parameters
true_w = np.log(np.ones(100) + 0.1 * np.random.randn(100))  # Example initial parameters
npop = 50 # population size
sigma = 0.0001  # noise standard deviation
alpha = 0.0001  # learning rate
iterations = 10000
tolerance = 1e-6
print('Tolerance:', tolerance)

print(0.5, 0.1, -0.3)

noisy_w = (0.01 * np.random.randn(100) + true_w)
x = 0.1 * np.random.randn(5000, 100)
z = np.round(np.exp(np.dot(x, true_w.reshape(-1,1))),4).reshape(-1)
y = np.round(np.exp(np.dot(x, noisy_w.reshape(-1,1))),4).reshape(-1)
print(y)
#raise()


# Call the optimization function
lib.init(npop, 100, iterations, tolerance)

w = np.ones(100)  # Example initial parameters
lib.optimize(w.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
             x.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
             y.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
             z.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
             1000, 100, npop, sigma, alpha, 5000)

print('------------------------------')

lib.optimize(w.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
             x.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
             y.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
             z.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
             1000, 100, npop, sigma, 0.000001, 5000)
             
print('Group splits of final parameters:')
lib.f(w.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
         x.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
         y.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
         z.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
         5000, 100, x.ctypes.data_as(ctypes.POINTER(ctypes.c_double)), 1)
print("--"*100)
lib.stop()

print("Optimized parameters (w):", np.exp(w))
print("--"*100)
print("True parameters (w):", np.exp(true_w))
print("--"*100)
print("Noisy parameters (w):", np.exp(noisy_w))
